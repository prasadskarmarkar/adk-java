# Selenium Automation Framework

A comprehensive test automation framework built with Selenium WebDriver, Java, Maven, and TestNG, featuring Page Object Model, data-driven testing, and rich HTML reporting.

## Features

- **Page Object Model (POM)** - Clean separation of page logic and test logic
- **Data-Driven Testing** - Excel-based test data management with Apache POI
- **Extent Reports** - Rich HTML reports with screenshots and detailed logs
- **WebDriverManager** - Automatic driver binary management (no manual downloads)
- **Multi-Browser Support** - Chrome, Firefox, and Edge
- **Configurable** - External configuration via properties file
- **Screenshot on Failure** - Automatic screenshot capture for debugging
- **Parallel Execution** - TestNG parallel test execution support
- **Logging** - Comprehensive test execution logging

## Project Structure

```
selenium-automation-framework/
├── src/
│   ├── main/
│   │   └── java/
│   │       ├── pages/           # Page Object Model classes
│   │       │   ├── BasePage.java
│   │       │   ├── LoginPage.java
│   │       │   └── HomePage.java
│   │       └── utils/           # Utility classes
│   │           ├── DriverManager.java
│   │           ├── ConfigReader.java
│   │           ├── ExcelReader.java
│   │           ├── ExtentReportManager.java
│   │           └── ScreenshotUtil.java
│   └── test/
│       ├── java/
│       │   └── tests/           # Test classes
│       │       ├── BaseTest.java
│       │       ├── LoginTest.java
│       │       └── SampleE2ETest.java
│       └── resources/
│           ├── testdata/        # Test data files
│           └── config.properties
├── extent-reports/              # Generated HTML reports
├── screenshots/                 # Test failure screenshots
├── test-output/                 # TestNG reports
├── pom.xml                      # Maven dependencies
├── testng.xml                   # TestNG suite configuration
└── README.md
```

## Prerequisites

- **Java JDK 11 or higher**
  - Download from: https://www.oracle.com/java/technologies/downloads/
  - Verify: `java -version`

- **Apache Maven 3.6 or higher**
  - Download from: https://maven.apache.org/download.cgi
  - Verify: `mvn -version`

- **IDE (Optional but recommended)**
  - IntelliJ IDEA, Eclipse, or VS Code with Java extensions

## Setup Instructions

### 1. Clone or Download the Project

```bash
cd selenium-automation-framework
```

### 2. Install Dependencies

```bash
mvn clean install
```

This will download all required dependencies including Selenium, TestNG, WebDriverManager, Extent Reports, and Apache POI.

### 3. Configure Test Settings

Edit `src/test/resources/config.properties`:

```properties
# Set your target website URL
baseUrl=https://your-website-url.com

# Choose browser (chrome, firefox, edge)
browser=chrome

# Enable/disable headless mode
headless=false

# Wait timeouts
implicitWait=10
explicitWait=20

# Screenshot on failure
screenshotOnFailure=true
```

### 4. Update Page Objects

The framework includes sample page objects (LoginPage, HomePage) with placeholder locators. Update them based on your target website:

1. Open `src/main/java/pages/LoginPage.java`
2. Update the `@FindBy` locators to match your website's HTML elements
3. Repeat for `HomePage.java` and create additional page objects as needed

Example:
```java
@FindBy(id = "username")  // Update this ID to match your website
private WebElement usernameField;
```

## Running Tests

### Run All Tests

```bash
mvn clean test
```

### Run Specific Test Suite

```bash
mvn clean test -DsuiteXmlFile=testng.xml
```

### Run Tests in Headless Mode

Update `config.properties`:
```properties
headless=true
```

Then run:
```bash
mvn clean test
```

### Run Tests with Different Browser

Update `config.properties`:
```properties
browser=firefox  # or edge
```

### Run from IDE

1. Right-click on `testng.xml`
2. Select "Run as TestNG Suite"

Or run individual test classes:
1. Right-click on any test class (e.g., `LoginTest.java`)
2. Select "Run as TestNG Test"

## Viewing Reports

### Extent Reports (Recommended)

After test execution, open the HTML report:

```
extent-reports/ExtentReport_[timestamp].html
```

Features:
- Test execution summary with pass/fail statistics
- Detailed step-by-step logs
- Screenshots attached to failed tests
- Browser and environment information
- Timeline view

### TestNG Reports

Default TestNG reports are generated at:

```
test-output/index.html
```

### Screenshots

Failed test screenshots are saved in:

```
screenshots/[test-name]_[timestamp].png
```

## Creating New Tests

### 1. Create a Page Object

```java
package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NewPage extends BasePage {

    @FindBy(id = "element-id")
    private WebElement element;

    public NewPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public void clickElement() {
        click(element);
    }
}
```

### 2. Create a Test Class

```java
package tests;

import org.testng.annotations.Test;
import pages.NewPage;
import utils.ExtentReportManager;

public class NewTest extends BaseTest {

    @Test
    public void testNewFeature() {
        ExtentReportManager.createTest("New Feature Test");

        NewPage newPage = new NewPage(driver);
        newPage.clickElement();

        ExtentReportManager.logPass("Test completed");
    }
}
```

### 3. Add Test to testng.xml

```xml
<test name="New Tests">
    <classes>
        <class name="tests.NewTest"/>
    </classes>
</test>
```

## Data-Driven Testing

### 1. Create Excel File

Create `src/test/resources/testdata/TestData.xlsx` with structure:

| username | password | expectedResult |
|----------|----------|----------------|
| user1    | pass123  | success        |
| user2    | pass456  | success        |

### 2. Use in Test

```java
@DataProvider(name = "testData")
public Object[][] getData() {
    String excelPath = "src/test/resources/testdata/TestData.xlsx";
    return ExcelReader.getTestData(excelPath, "SheetName");
}

@Test(dataProvider = "testData")
public void testWithData(String username, String password, String expected) {
    // Your test logic
}
```

## Best Practices

1. **Keep Page Objects Clean**
   - Only include page-specific elements and actions
   - Use BasePage for common functionality

2. **Use Explicit Waits**
   - All BasePage methods include proper waits
   - Avoid Thread.sleep()

3. **Meaningful Test Names**
   - Use descriptive test method names
   - Add descriptions in @Test annotation

4. **Log Important Steps**
   - Use ExtentReportManager for logging
   - Log test steps for better debugging

5. **Organize Test Data**
   - Keep test data separate from test code
   - Use Excel files for complex data sets

6. **Handle Assertions Properly**
   - Use TestNG assertions
   - Provide meaningful assertion messages

## Parallel Execution

To run tests in parallel, update `testng.xml`:

```xml
<suite name="Test Suite" parallel="tests" thread-count="3">
    <!-- Your tests -->
</suite>
```

Options:
- `parallel="tests"` - Run test tags in parallel
- `parallel="classes"` - Run test classes in parallel
- `parallel="methods"` - Run test methods in parallel

## Troubleshooting

### Tests fail to start browser

- Ensure WebDriverManager is downloading drivers (check internet connection)
- Verify browser is installed on your system
- Check browser version compatibility

### Element not found errors

- Update locators in Page Object classes to match your website
- Increase wait times in config.properties
- Use browser DevTools to verify element selectors

### Maven dependency issues

```bash
mvn clean install -U
```

### Reports not generating

- Check file permissions in extent-reports directory
- Ensure ExtentReportManager.flushReports() is called in @AfterSuite

## Customization

### Add More Browsers

Update `DriverManager.java`:

```java
case "safari":
    WebDriverManager.safaridriver().setup();
    driver.set(new SafariDriver());
    break;
```

### Add Custom Utilities

Create new utility classes in `src/main/java/utils/`

### Integrate with CI/CD

Add to Jenkins, GitHub Actions, or GitLab CI:

```yaml
# Example GitHub Actions
- name: Run Tests
  run: mvn clean test
```

## Contributing

1. Create feature branch
2. Add your changes
3. Update documentation
4. Submit pull request

## License

This framework is open source and available for use in your automation projects.

## Support

For issues or questions:
- Check documentation above
- Review sample tests in the project
- Examine Page Object implementations

## Next Steps

1. Update page objects with your website's actual locators
2. Create additional page objects for other pages
3. Write test cases for your application features
4. Set up data-driven tests with Excel files
5. Integrate with your CI/CD pipeline
6. Customize reports and logging as needed

Happy Testing!
