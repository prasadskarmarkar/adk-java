# Quick Start Guide

Get started with the Selenium Automation Framework in 5 minutes!

## Prerequisites Check

Verify you have Java and Maven installed:

```bash
java -version   # Should be 11 or higher
mvn -version    # Should be 3.6 or higher
```

If not installed:
- **Java**: https://www.oracle.com/java/technologies/downloads/
- **Maven**: https://maven.apache.org/download.cgi

## Step 1: Navigate to Project

```bash
cd selenium-automation-framework
```

## Step 2: Install Dependencies

```bash
mvn clean install
```

This will download all required libraries (Selenium, TestNG, etc.)

## Step 3: Configure Your Target Website

Edit `src/test/resources/config.properties`:

```properties
baseUrl=https://your-website-url.com
browser=chrome
headless=false
```

## Step 4: Update Page Locators

Since every website is different, you need to update the element locators in the page objects.

### Example: Updating LoginPage

1. Open your target website in a browser
2. Right-click on the username field and select "Inspect"
3. Find the element's id, name, or other attributes
4. Update `src/main/java/pages/LoginPage.java`:

```java
// BEFORE (placeholder)
@FindBy(id = "username")
private WebElement usernameField;

// AFTER (your actual website)
@FindBy(id = "user-email")  // Use your actual element ID
private WebElement usernameField;
```

Repeat for all elements in LoginPage and HomePage.

## Step 5: Run Your First Test

```bash
mvn clean test
```

This will:
1. Launch Chrome browser
2. Navigate to your configured website
3. Run the sample tests
4. Generate reports

## Step 6: View Reports

After tests run, open the report:

```bash
# On macOS
open extent-reports/ExtentReport_*.html

# On Windows
start extent-reports/ExtentReport_*.html

# On Linux
xdg-open extent-reports/ExtentReport_*.html
```

## What's Next?

### 1. Create Page Objects for Your Website

Create a new page class for each page you want to test:

```bash
# Example structure
src/main/java/pages/
  ├── LoginPage.java      # ✓ Already created (update locators)
  ├── HomePage.java       # ✓ Already created (update locators)
  ├── ProductPage.java    # Create this for your product page
  └── CheckoutPage.java   # Create this for checkout
```

### 2. Write Tests

Create test classes in `src/test/java/tests/`:

```java
package tests;

import org.testng.annotations.Test;
import pages.ProductPage;
import utils.ExtentReportManager;

public class ProductTest extends BaseTest {

    @Test
    public void testAddToCart() {
        ExtentReportManager.createTest("Add to Cart Test");

        ProductPage productPage = new ProductPage(driver);
        productPage.clickAddToCart();

        ExtentReportManager.logPass("Product added to cart");
    }
}
```

### 3. Add to TestNG Suite

Update `testng.xml`:

```xml
<test name="Product Tests">
    <classes>
        <class name="tests.ProductTest"/>
    </classes>
</test>
```

## Common Tasks

### Run Tests in Different Browser

```properties
# In config.properties
browser=firefox  # or edge
```

### Run Tests in Headless Mode

```properties
# In config.properties
headless=true
```

### Run Specific Test Class

```bash
mvn test -Dtest=LoginTest
```

### Run Specific Test Method

```bash
mvn test -Dtest=LoginTest#testValidLogin
```

## Troubleshooting

### Browser doesn't open
- Ensure Chrome/Firefox is installed
- Check internet connection (WebDriverManager needs to download drivers)

### Element not found errors
- Update locators in page objects to match your website
- Increase wait times in config.properties

### Compilation errors
```bash
mvn clean compile
```

## Need More Help?

1. Read the full README.md for detailed documentation
2. Check sample tests in `src/test/java/tests/`
3. Review page object examples in `src/main/java/pages/`

## File Structure Reference

```
selenium-automation-framework/
├── src/
│   ├── main/java/
│   │   ├── pages/          # UPDATE: Page objects with element locators
│   │   └── utils/          # DON'T CHANGE: Framework utilities
│   └── test/
│       ├── java/tests/     # CREATE: Your test cases
│       └── resources/
│           ├── config.properties  # UPDATE: Configuration
│           └── testdata/          # CREATE: Test data Excel files
├── pom.xml                 # DON'T CHANGE: Dependencies
└── testng.xml             # UPDATE: Add your test classes here
```

Ready to start testing! 🚀
