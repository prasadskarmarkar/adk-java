package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.ConfigReader;

import java.time.Duration;

/**
 * Base Page Class
 * Contains common methods that can be reused across all page objects
 */
public class BasePage {

    protected WebDriver driver;
    protected WebDriverWait wait;
    protected ConfigReader configReader;

    /**
     * Constructor
     * @param driver WebDriver instance
     */
    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.configReader = new ConfigReader();
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(configReader.getExplicitWait()));
    }

    /**
     * Click on element
     * @param element WebElement to click
     */
    protected void click(WebElement element) {
        waitForElementClickable(element);
        element.click();
    }

    /**
     * Send keys to element
     * @param element WebElement
     * @param text Text to enter
     */
    protected void sendKeys(WebElement element, String text) {
        waitForElementVisible(element);
        element.clear();
        element.sendKeys(text);
    }

    /**
     * Get text from element
     * @param element WebElement
     * @return Element text
     */
    protected String getText(WebElement element) {
        waitForElementVisible(element);
        return element.getText();
    }

    /**
     * Wait for element to be visible
     * @param element WebElement
     * @return WebElement
     */
    protected WebElement waitForElementVisible(WebElement element) {
        return wait.until(ExpectedConditions.visibilityOf(element));
    }

    /**
     * Wait for element to be clickable
     * @param element WebElement
     * @return WebElement
     */
    protected WebElement waitForElementClickable(WebElement element) {
        return wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    /**
     * Check if element is displayed
     * @param element WebElement
     * @return true if element is displayed
     */
    protected boolean isElementDisplayed(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Check if element is enabled
     * @param element WebElement
     * @return true if element is enabled
     */
    protected boolean isElementEnabled(WebElement element) {
        try {
            return element.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Scroll to element
     * @param element WebElement to scroll to
     */
    protected void scrollToElement(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }

    /**
     * Select dropdown option by visible text
     * @param dropdown Dropdown element
     * @param text Visible text to select
     */
    protected void selectDropdownByText(WebElement dropdown, String text) {
        Select select = new Select(dropdown);
        select.selectByVisibleText(text);
    }

    /**
     * Select dropdown option by value
     * @param dropdown Dropdown element
     * @param value Value to select
     */
    protected void selectDropdownByValue(WebElement dropdown, String value) {
        Select select = new Select(dropdown);
        select.selectByValue(value);
    }

    /**
     * Select dropdown option by index
     * @param dropdown Dropdown element
     * @param index Index to select
     */
    protected void selectDropdownByIndex(WebElement dropdown, int index) {
        Select select = new Select(dropdown);
        select.selectByIndex(index);
    }

    /**
     * Get page title
     * @return Page title
     */
    public String getPageTitle() {
        return driver.getTitle();
    }

    /**
     * Get current URL
     * @return Current URL
     */
    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    /**
     * Execute JavaScript
     * @param script JavaScript code
     * @param args Arguments for the script
     * @return Script execution result
     */
    protected Object executeJavaScript(String script, Object... args) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        return js.executeScript(script, args);
    }

    /**
     * Wait for page load complete
     */
    protected void waitForPageLoad() {
        wait.until(driver ->
            ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete")
        );
    }
}
