package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * Login Page Object
 * Represents the login page and its elements
 * NOTE: Update the locators based on your actual website's HTML structure
 */
public class LoginPage extends BasePage {

    // Page Elements using @FindBy annotations
    @FindBy(id = "username")
    private WebElement usernameField;

    @FindBy(id = "password")
    private WebElement passwordField;

    @FindBy(id = "login-button")
    private WebElement loginButton;

    @FindBy(className = "error-message")
    private WebElement errorMessage;

    @FindBy(xpath = "//a[contains(text(),'Forgot Password')]")
    private WebElement forgotPasswordLink;

    /**
     * Constructor
     * @param driver WebDriver instance
     */
    public LoginPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * Enter username
     * @param username Username to enter
     */
    public void enterUsername(String username) {
        sendKeys(usernameField, username);
    }

    /**
     * Enter password
     * @param password Password to enter
     */
    public void enterPassword(String password) {
        sendKeys(passwordField, password);
    }

    /**
     * Click login button
     */
    public void clickLoginButton() {
        click(loginButton);
    }

    /**
     * Perform login action
     * @param username Username
     * @param password Password
     * @return HomePage object after successful login
     */
    public HomePage login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
        return new HomePage(driver);
    }

    /**
     * Get error message text
     * @return Error message
     */
    public String getErrorMessage() {
        return getText(errorMessage);
    }

    /**
     * Check if error message is displayed
     * @return true if error message is displayed
     */
    public boolean isErrorMessageDisplayed() {
        return isElementDisplayed(errorMessage);
    }

    /**
     * Click forgot password link
     */
    public void clickForgotPassword() {
        click(forgotPasswordLink);
    }

    /**
     * Verify login page is loaded
     * @return true if login page is loaded
     */
    public boolean isLoginPageLoaded() {
        return isElementDisplayed(loginButton) &&
               isElementDisplayed(usernameField) &&
               isElementDisplayed(passwordField);
    }
}
