package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * Home Page Object
 * Represents the home page after successful login
 * NOTE: Update the locators based on your actual website's HTML structure
 */
public class HomePage extends BasePage {

    // Page Elements using @FindBy annotations
    @FindBy(id = "welcome-message")
    private WebElement welcomeMessage;

    @FindBy(xpath = "//a[contains(text(),'Dashboard')]")
    private WebElement dashboardLink;

    @FindBy(id = "user-profile")
    private WebElement userProfile;

    @FindBy(id = "logout-button")
    private WebElement logoutButton;

    @FindBy(className = "main-menu")
    private WebElement mainMenu;

    @FindBy(xpath = "//a[contains(text(),'Settings')]")
    private WebElement settingsLink;

    /**
     * Constructor
     * @param driver WebDriver instance
     */
    public HomePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * Get welcome message text
     * @return Welcome message
     */
    public String getWelcomeMessage() {
        return getText(welcomeMessage);
    }

    /**
     * Check if welcome message is displayed
     * @return true if welcome message is displayed
     */
    public boolean isWelcomeMessageDisplayed() {
        return isElementDisplayed(welcomeMessage);
    }

    /**
     * Click dashboard link
     */
    public void clickDashboard() {
        click(dashboardLink);
    }

    /**
     * Click user profile
     */
    public void clickUserProfile() {
        click(userProfile);
    }

    /**
     * Click logout button
     * @return LoginPage object after logout
     */
    public LoginPage logout() {
        click(logoutButton);
        return new LoginPage(driver);
    }

    /**
     * Click settings link
     */
    public void clickSettings() {
        click(settingsLink);
    }

    /**
     * Verify home page is loaded
     * @return true if home page is loaded
     */
    public boolean isHomePageLoaded() {
        return isElementDisplayed(welcomeMessage) ||
               isElementDisplayed(mainMenu);
    }

    /**
     * Get page title
     * @return Page title
     */
    public String getHomePageTitle() {
        return getPageTitle();
    }

    /**
     * Check if user is logged in
     * @return true if user profile is displayed
     */
    public boolean isUserLoggedIn() {
        return isElementDisplayed(userProfile);
    }
}
