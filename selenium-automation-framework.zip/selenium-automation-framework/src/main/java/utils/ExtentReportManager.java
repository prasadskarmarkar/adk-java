package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Extent Report Manager
 * Manages ExtentReports for test execution reporting
 */
public class ExtentReportManager {

    private static ExtentReports extentReports;
    private static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();
    private static String reportPath;

    /**
     * Initialize Extent Reports
     */
    public static void initReports() {
        if (extentReports == null) {
            String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
            reportPath = "extent-reports/ExtentReport_" + timestamp + ".html";

            // Create extent-reports directory if it doesn't exist
            File reportDir = new File("extent-reports");
            if (!reportDir.exists()) {
                reportDir.mkdirs();
            }

            ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
            sparkReporter.config().setTheme(Theme.STANDARD);
            sparkReporter.config().setDocumentTitle("Test Automation Report");
            sparkReporter.config().setReportName("Selenium Test Execution Report");
            sparkReporter.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss");

            extentReports = new ExtentReports();
            extentReports.attachReporter(sparkReporter);
            extentReports.setSystemInfo("OS", System.getProperty("os.name"));
            extentReports.setSystemInfo("Java Version", System.getProperty("java.version"));
            extentReports.setSystemInfo("User", System.getProperty("user.name"));
        }
    }

    /**
     * Create a new test in the report
     * @param testName Name of the test
     * @return ExtentTest instance
     */
    public static ExtentTest createTest(String testName) {
        ExtentTest test = extentReports.createTest(testName);
        extentTest.set(test);
        return test;
    }

    /**
     * Create a new test with description
     * @param testName Name of the test
     * @param description Test description
     * @return ExtentTest instance
     */
    public static ExtentTest createTest(String testName, String description) {
        ExtentTest test = extentReports.createTest(testName, description);
        extentTest.set(test);
        return test;
    }

    /**
     * Get current test instance
     * @return ExtentTest instance for current thread
     */
    public static ExtentTest getTest() {
        return extentTest.get();
    }

    /**
     * Log info message
     * @param message Message to log
     */
    public static void logInfo(String message) {
        getTest().log(Status.INFO, message);
    }

    /**
     * Log pass message
     * @param message Message to log
     */
    public static void logPass(String message) {
        getTest().log(Status.PASS, message);
    }

    /**
     * Log fail message
     * @param message Message to log
     */
    public static void logFail(String message) {
        getTest().log(Status.FAIL, message);
    }

    /**
     * Log skip message
     * @param message Message to log
     */
    public static void logSkip(String message) {
        getTest().log(Status.SKIP, message);
    }

    /**
     * Log warning message
     * @param message Message to log
     */
    public static void logWarning(String message) {
        getTest().log(Status.WARNING, message);
    }

    /**
     * Attach screenshot to report
     * @param screenshotPath Path to screenshot file
     */
    public static void attachScreenshot(String screenshotPath) {
        try {
            getTest().addScreenCaptureFromPath(screenshotPath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Flush reports (write to file)
     */
    public static void flushReports() {
        if (extentReports != null) {
            extentReports.flush();
            System.out.println("Extent Report generated at: " + reportPath);
        }
    }

    /**
     * Get report path
     * @return Path to the report file
     */
    public static String getReportPath() {
        return reportPath;
    }
}
