package utils;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Screenshot Utility
 * Captures and saves screenshots for test failures and debugging
 */
public class ScreenshotUtil {

    /**
     * Capture screenshot
     * @param driver WebDriver instance
     * @param screenshotName Name for the screenshot
     * @return Path to saved screenshot
     */
    public static String captureScreenshot(WebDriver driver, String screenshotName) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
        String fileName = screenshotName + "_" + timestamp + ".png";
        String screenshotPath = "screenshots/" + fileName;

        try {
            // Create screenshots directory if it doesn't exist
            File screenshotDir = new File("screenshots");
            if (!screenshotDir.exists()) {
                screenshotDir.mkdirs();
            }

            // Capture screenshot
            TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
            File sourceFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
            File destinationFile = new File(screenshotPath);

            // Copy screenshot to destination
            FileUtils.copyFile(sourceFile, destinationFile);

            System.out.println("Screenshot captured: " + screenshotPath);
            return screenshotPath;

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Failed to capture screenshot: " + screenshotName);
            return null;
        }
    }

    /**
     * Capture screenshot with default naming
     * @param driver WebDriver instance
     * @return Path to saved screenshot
     */
    public static String captureScreenshot(WebDriver driver) {
        return captureScreenshot(driver, "screenshot");
    }

    /**
     * Get absolute path for screenshot
     * @param screenshotPath Relative screenshot path
     * @return Absolute path
     */
    public static String getAbsolutePath(String screenshotPath) {
        File file = new File(screenshotPath);
        return file.getAbsolutePath();
    }
}
