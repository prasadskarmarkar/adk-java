package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Configuration Reader
 * Reads and provides access to properties from config.properties file
 */
public class ConfigReader {

    private Properties properties;
    private static final String CONFIG_FILE_PATH = "src/test/resources/config.properties";

    public ConfigReader() {
        properties = new Properties();
        loadProperties();
    }

    /**
     * Load properties from config file
     */
    private void loadProperties() {
        try {
            FileInputStream fis = new FileInputStream(CONFIG_FILE_PATH);
            properties.load(fis);
            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load config.properties file from: " + CONFIG_FILE_PATH);
        }
    }

    /**
     * Get browser type
     * @return Browser name (chrome, firefox, edge)
     */
    public String getBrowser() {
        return properties.getProperty("browser", "chrome");
    }

    /**
     * Get base URL
     * @return Base URL for the application under test
     */
    public String getBaseUrl() {
        return properties.getProperty("baseUrl");
    }

    /**
     * Get implicit wait timeout
     * @return Implicit wait in seconds
     */
    public int getImplicitWait() {
        return Integer.parseInt(properties.getProperty("implicitWait", "10"));
    }

    /**
     * Get explicit wait timeout
     * @return Explicit wait in seconds
     */
    public int getExplicitWait() {
        return Integer.parseInt(properties.getProperty("explicitWait", "20"));
    }

    /**
     * Check if headless mode is enabled
     * @return true if headless mode enabled
     */
    public boolean isHeadless() {
        return Boolean.parseBoolean(properties.getProperty("headless", "false"));
    }

    /**
     * Check if screenshot on failure is enabled
     * @return true if screenshot should be captured on failure
     */
    public boolean isScreenshotOnFailure() {
        return Boolean.parseBoolean(properties.getProperty("screenshotOnFailure", "true"));
    }

    /**
     * Get property value by key
     * @param key Property key
     * @return Property value
     */
    public String getProperty(String key) {
        return properties.getProperty(key);
    }
}
