# Sample Test Data

This directory contains test data files for data-driven testing.

## Excel File Structure

To create an Excel file for test data:

1. Create a new Excel file named "TestData.xlsx"
2. Create sheets with test data (e.g., "LoginData", "UserData")
3. First row should contain column headers
4. Subsequent rows contain test data

Example structure for LoginData sheet:

| username              | password    | expectedResult |
|-----------------------|-------------|----------------|
| user1@example.com     | Password123 | success        |
| user2@example.com     | Pass456     | success        |
| invalid@test.com      | WrongPass   | failure        |

## Using Test Data in Tests

In your test class, use the ExcelReader utility:

```java
@DataProvider(name = "loginData")
public Object[][] getLoginData() {
    String excelPath = "src/test/resources/testdata/TestData.xlsx";
    return ExcelReader.getTestData(excelPath, "LoginData");
}

@Test(dataProvider = "loginData")
public void testLogin(String username, String password, String expectedResult) {
    // Your test code here
}
```

## Note

The Excel file is not included by default. You need to create it based on your specific test requirements.
You can use Microsoft Excel, LibreOffice Calc, or Google Sheets to create the file.
