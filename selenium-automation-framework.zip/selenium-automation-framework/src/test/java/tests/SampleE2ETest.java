package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import utils.ExtentReportManager;

/**
 * Sample End-to-End Test Class
 * Demonstrates a complete user journey across multiple pages
 */
public class SampleE2ETest extends BaseTest {

    /**
     * End-to-End test: Login, navigate, and logout
     */
    @Test(priority = 1, description = "Complete user journey - Login to Logout")
    public void testCompleteUserJourney() {
        ExtentReportManager.createTest("End-to-End User Journey",
            "Test complete flow from login to logout");

        // Step 1: Login
        LoginPage loginPage = new LoginPage(driver);
        ExtentReportManager.logInfo("Step 1: Navigated to login page");

        HomePage homePage = loginPage.login("testuser@example.com", "Password123");
        ExtentReportManager.logPass("Step 1: Successfully logged in");

        // Step 2: Verify home page
        // NOTE: Update assertions based on actual website
        // Assert.assertTrue(homePage.isHomePageLoaded(), "Home page should be loaded");
        ExtentReportManager.logInfo("Step 2: Home page verified");

        // Step 3: Navigate to Dashboard
        homePage.clickDashboard();
        ExtentReportManager.logInfo("Step 3: Navigated to Dashboard");

        // Step 4: Navigate to Settings
        homePage.clickSettings();
        ExtentReportManager.logInfo("Step 4: Navigated to Settings");

        // Step 5: Logout
        LoginPage returnedLoginPage = homePage.logout();
        ExtentReportManager.logPass("Step 5: Successfully logged out");

        // Verify returned to login page
        // Assert.assertTrue(returnedLoginPage.isLoginPageLoaded(), "Should return to login page after logout");
        ExtentReportManager.logPass("End-to-End test completed successfully");
    }

    /**
     * Test navigation across multiple pages
     */
    @Test(priority = 2, description = "Test navigation across different sections")
    public void testNavigation() {
        ExtentReportManager.createTest("Navigation Test", "Test navigation functionality");

        // Login
        LoginPage loginPage = new LoginPage(driver);
        HomePage homePage = loginPage.login("testuser@example.com", "Password123");
        ExtentReportManager.logInfo("Logged in successfully");

        // Navigate to different sections
        homePage.clickDashboard();
        ExtentReportManager.logInfo("Navigated to Dashboard");

        // Verify page title or URL
        String currentUrl = homePage.getCurrentUrl();
        ExtentReportManager.logInfo("Current URL: " + currentUrl);

        homePage.clickUserProfile();
        ExtentReportManager.logInfo("Clicked on User Profile");

        ExtentReportManager.logPass("Navigation test completed");
    }

    /**
     * Test user profile functionality
     */
    @Test(priority = 3, description = "Verify user profile functionality")
    public void testUserProfile() {
        ExtentReportManager.createTest("User Profile Test", "Test user profile features");

        // Login
        LoginPage loginPage = new LoginPage(driver);
        HomePage homePage = loginPage.login("testuser@example.com", "Password123");
        ExtentReportManager.logInfo("Logged in successfully");

        // Check if user is logged in
        // NOTE: Update based on actual website
        // Assert.assertTrue(homePage.isUserLoggedIn(), "User should be logged in");
        ExtentReportManager.logPass("User profile verified");

        // Get welcome message
        // String welcomeMsg = homePage.getWelcomeMessage();
        // ExtentReportManager.logInfo("Welcome message: " + welcomeMsg);

        ExtentReportManager.logPass("User profile test completed");
    }

    /**
     * Test page title verification
     */
    @Test(priority = 4, description = "Verify page titles across application")
    public void testPageTitles() {
        ExtentReportManager.createTest("Page Title Test", "Verify correct page titles");

        LoginPage loginPage = new LoginPage(driver);
        String loginPageTitle = loginPage.getPageTitle();
        ExtentReportManager.logInfo("Login page title: " + loginPageTitle);

        // Login and verify home page title
        HomePage homePage = loginPage.login("testuser@example.com", "Password123");
        String homePageTitle = homePage.getHomePageTitle();
        ExtentReportManager.logInfo("Home page title: " + homePageTitle);

        // NOTE: Add assertions based on expected titles
        // Assert.assertTrue(homePageTitle.contains("Home"), "Home page title should contain 'Home'");

        ExtentReportManager.logPass("Page title verification completed");
    }
}
