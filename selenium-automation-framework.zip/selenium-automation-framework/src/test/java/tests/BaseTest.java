package tests;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;
import utils.ConfigReader;
import utils.DriverManager;
import utils.ExtentReportManager;
import utils.ScreenshotUtil;

/**
 * Base Test Class
 * Contains setup and teardown methods for all test classes
 */
public class BaseTest {

    protected WebDriver driver;
    protected ConfigReader configReader;

    /**
     * Before Suite - Initialize Extent Reports
     */
    @BeforeSuite
    public void beforeSuite() {
        ExtentReportManager.initReports();
        System.out.println("=== Test Suite Started ===");
    }

    /**
     * Before Class - Setup before test class execution
     */
    @BeforeClass
    public void beforeClass() {
        configReader = new ConfigReader();
        System.out.println("Test Class: " + this.getClass().getSimpleName());
    }

    /**
     * Before Method - Setup before each test method
     * Initializes WebDriver and navigates to base URL
     */
    @BeforeMethod
    public void setUp() {
        driver = DriverManager.getDriver();
        DriverManager.navigateToBaseUrl();
        ExtentReportManager.logInfo("Browser launched and navigated to: " + configReader.getBaseUrl());
    }

    /**
     * After Method - Cleanup after each test method
     * Captures screenshot on failure and quits driver
     */
    @AfterMethod
    public void tearDown(ITestResult result) {
        // Check if test failed
        if (result.getStatus() == ITestResult.FAILURE) {
            ExtentReportManager.logFail("Test Failed: " + result.getName());
            ExtentReportManager.logFail("Failure Reason: " + result.getThrowable());

            // Capture screenshot if enabled
            if (configReader.isScreenshotOnFailure()) {
                String screenshotPath = ScreenshotUtil.captureScreenshot(driver, result.getName());
                if (screenshotPath != null) {
                    ExtentReportManager.attachScreenshot(screenshotPath);
                    ExtentReportManager.logInfo("Screenshot captured for failed test");
                }
            }
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            ExtentReportManager.logPass("Test Passed: " + result.getName());
        } else if (result.getStatus() == ITestResult.SKIP) {
            ExtentReportManager.logSkip("Test Skipped: " + result.getName());
        }

        // Quit driver
        DriverManager.quitDriver();
    }

    /**
     * After Suite - Flush Extent Reports
     */
    @AfterSuite
    public void afterSuite() {
        ExtentReportManager.flushReports();
        System.out.println("=== Test Suite Completed ===");
    }
}
